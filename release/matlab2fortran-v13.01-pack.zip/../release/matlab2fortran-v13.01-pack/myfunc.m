function z = myfunc(x) 
% Doc example.  Chapter 4.
% $Revision: 1.1 $
temp1 = x .* 10 .* sin(x); 
z = round(temp1);
