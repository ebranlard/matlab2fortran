% function [a s b i f]=fnull(x,a,i,h,f);
function [i]=fnull(i,arg2);

A(1,:)=schtroumf;


D(1,:)=[1 2 c(2)];
K(:,2)=[12 12 12 , 1 2 c(2)];

i=1;
b=ones(1,2);

i=[1;1;1];
h=zeros(1);

i=zeros(2,1);

Prout=[a 'kdsjfkdsjf ksjdlfsd'  s];


K=a+b(1:10)'


Ui=[x' y' z'];



stack=[] ;
stack{end}= [ addme ] ;

if (a) && b
    youpi
end
if (a) && (b)
    youpi
end
if a && b
    youpi
end
if (a && b)
    youpi
end
% s=zeros(2,1);
end



