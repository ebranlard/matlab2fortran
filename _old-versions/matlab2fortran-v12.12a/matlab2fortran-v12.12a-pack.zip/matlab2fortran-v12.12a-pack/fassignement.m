function [ s , decl_stack ] = fassignement( s , decl_stack )
% only simple assignments are allowed x1_var =... , I.element =
% It is chosen to keep the dot in the variable name...
% if an assignment is of the form a(:,1) we dont cons
%

Ieq=strfind(s,'=');
if ~isempty(Ieq)
    Is=regexp(s,'[a-z.A-Z0-9_ ]+=');
    if ~isempty(Is) && Is(1)==1
        v.name=strtrim(s(1:(Ieq(1)-1)));
    else
        v.name='TODO';
    end
    [v.type, v.shape, v.prop] =fgetVarTypeFromName(v.name);
    v.comment='';
    decl_stack=fstack_push(decl_stack,v);
end


end %function

