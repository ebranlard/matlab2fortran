function [  ] = matlab2fortran( varargin )
%matlab2fortran(matlab to fortran) : converting matlab code to fortran

% Author:Emmanuel Branlard
% Date  : December 2012
% Version: 0.12.12a

% License: None. Thank you for sharing your improvements to me by email.

% Revision: 
%           15/12/12 : added declaration of variables at beginning of script or subroutines
%                      added handling of intent(inout), 
%                      corrected small bug for do loops and number of ":" since they can be in length(a(:,1)) 
%                      


%matlab2fortran(matlab to fortran) is a code that performs an automatic conversion of one or multiple matlab files to fortran format.The script translate some of the main features of matlab to fortran. matlab2fortran performs a quick and dirty conversion based on a line-by-line basis (but still supports conditional loops and subroutine). The script allows multiple matlab command per line if these commands are separated by ";", but not by ",".

%matlab2fortran does not intend to produce ready-to-compile code, but performs several necessary conversions. The generated code keeps the structure, variables names and comments of the original code. 

%The script matlab2fortran (matlab to fortran) is a single script file written in matlab and does not require a particular installation other than maybe adding this script to your current folder or matlab path. The script has been tested on linux and windows.

%Main Features of matlab2fortran:
%- conversion of nested structure: do, if, switch (select), while
%- conversion of function to subroutine with recognition of output and input arguments
%- perform subroutine list of arguments with intent(in) and intent(out)
%- make a declaration list for simple variable , sort them by Name or Type 
%- determines type based on variable name (function fgetVarTypeFromVarName)
%- recognize simple function call and convert them to subroutine calls (syntax [y] = f(x) );
%- performs allocation when converting matlab function zeros, ones (linspace possible)
%- splitting of lines that contain multiple matlab command separated by ;
%- comments
%- small support for sprintf and fprintf
%- misc conversions such as logical operators
%- few intrinsic functions conversion

%TODOs:
%- better printf handling
%- Handling of [] and string concanenation
%- better handling of function calls and nested function calls..




% example 1:
% matlab2fortran('tests/test1.m');
% matlab2fortran('tests/test1.m','tests/test2.m');

% example 2: all files in current directory (does not work with subfolders with dir..)
% FileList=dir('*.m');
% matlab2fortran(FileList.name);

%% Parameters
bDebug=0;% show input in stdout
bPipe=0; % pipe output to stdout
bSortDeclarationbyNames=1; %
bSortDeclarationbyTypes=0; %

%%
if nargin==0
    error('Empty file list')
end

%% dealing with multiple input files "recursively..."
if length(varargin)>1
    for ifile = 1:length(varargin)
        f=varargin{ifile};
        matlab2fortran(f);
    end
else
    %% One file call
    file=varargin{1};
    fidm=fopen(file,'r');
    if fidm==-1
        error(['Unable to open input file: ' file]);
    end


    filef=regexprep(file,'\.m$','.f90');
    fileftmp=regexprep(file,'\.m$','_tmp.f90');
    fprintf('Converting to file: %s\n',filef);
    %     warning off
    if ~bDebug
        fidftmp=fopen(fileftmp,'w');
        if fidftmp==-1
            error(['Unable to open temporary output file: ' fileftmp]);
        end
        fidf=fopen(filef,'w');
        if fidf==-1
            error(['Unable to open output file: ' filef]);
        end
    else
        fidftmp=1; % standard output 
        fidf=1; % standard output 
    end
    %% Conversion line by line and ouput to file
    if ~bDebug
        warning off ; %WATCH OUT
    end
    [Declarations]=fconvertlinebyline(fidm,fidftmp,bDebug,bPipe);
    warning on
    fclose(fidm);
    if ~bDebug 
        fclose(fidftmp);
    end


    %% Sorting Declarations for each subroutine and main program
    Declarations=fFormatDeclarations(Declarations,bSortDeclarationbyNames,bSortDeclarationbyTypes,bDebug);


    %% Reading temp file, outputting to final file with declarations , only possible without Debug
    if ~bDebug
        fidftmp=fopen(fileftmp,'r');
        if fidftmp==-1
            error(['Unable to re open temporary output file: ' fileftmp]);
        end
        fWriteDeclarationsAtCorrectLocation(fidftmp,fidf,Declarations)
        fclose(fidftmp);
        delete(fileftmp);
        fclose(fidf);
    end % end output of declaration if not debug mode
end % end switch between one or two files

end %function



function [Declarations]=fconvertlinebyline(fidm,fidf,bDebug,bPipe)
sLine = fgets(fidm);
end_stack=[];
current_unit=1;
Declarations{current_unit}=[]; % contains all variables declaration
decl_stack=[];  % contains variable declaration for current subroutine or main..
pref_in='';
pref_out='';
if bDebug 
    pref_in='In :';
    pref_out='Out:';
end
while sLine ~= -1
    % remove useless spaces 
    sLine=strtrim(sLine);
    sLine=fremovespaces(sLine);

    if bDebug 
        fprintf('%s%s \n',pref_in,sLine);
    end

    % Simple case: emptyline
    if isempty(sLine)
        sf=[sLine '\n'];
        fprintf(fidf,[pref_out,sf]);
        if bPipe ; fprintf(1,[pref_out,sf]); end
    % Simple case: start with a comment, still needs small handling
    elseif sLine(1)=='%'
%         kbd
        sLine(1)='!';
         sLine=strrep(sLine,'%','!');
%          sLine=strrep(sLine,'%','!');
        sLine=strrep(sLine,'\n','NewLine'); 
        sLine=strrep(sLine,'\','\\'); 
        sf=[sLine ' \n'];
%         sf=strrep(sf,'%','%%');
        fprintf(fidf,[pref_out,sf]);
        if bPipe ; fprintf(1,[pref_out,sf]); end
    else
        % the problematic printf case is dealt then
        if ~isempty(regexp(sLine,'[fs]+printf\(')) 
            [ sf ] = freplaceprintf( sLine );
            fprintf(fidf,[pref_out,sf]);
            if bPipe ; fprintf(1,[pref_out,sf]); end
        else
            % comments replacement
            sLine=strrep(sLine,'%','!');
            % splitting matlab lines if commands on the same line
            [ sout ] = fsplitmatlablines( sLine,[] );
            for isplit=1:length(sout)
                s=sout{isplit};
                % ---------------------------------
                % The Main function
                % ---------------------------------
                [sf end_stack decl_stack unit_switch]=fconvertline(s,end_stack,decl_stack);
                if unit_switch~=0 
                    % storing the stack of declaration of previous unit
                    if bDebug
                        disp('Entering new unit')
                    end
                    Declarations{current_unit}=decl_stack;
                    current_unit=current_unit+unit_switch;
                    if unit_switch==1 
                        Declarations{current_unit}=[];
                        decl_stack=[];
                    end
                end
                % ---------------------------------
                sf=fremovespaces(sf);
                fprintf(fidf,[pref_out,sf]);
                if bPipe ; fprintf(1,[pref_out,sf]); end
            end
        end
    end
    sLine = fgets(fidm);
end

Declarations{current_unit}=decl_stack;

% if at the end we still have some end, output them
for ie=1:length(end_stack)
    fprintf(fidf,'end %s \n',end_stack{ie});
end

end %function


function [sf end_stack decl_stack unit_switch]=fconvertline(s,end_stack,decl_stack)
unit_switch=0;
% function replace
I=strfind(s,'function');
if ~isempty(I) && I(1)==1
    [ sf end_stack ] = freplacefunction( s , end_stack );
    unit_switch=1; %we are entering a new unit
    return;
end

%% Simple regexprep or rep
% logical
s=regexprep(s,'~=','/=');
s=regexprep(s,'~(.*)','.not.($1)');
s=strrep(s,'&&','.and.');
s=strrep(s,'||','.or.');
s=strrep(s,'break','exit');
s=strrep(s,'true','.true.');
s=strrep(s,'false','.false.');

% intrisic
s=strrep(s,'strtrim(','trim(');
s=strrep(s,'ceil(','ceiling(');
s=strrep(s,'round(','anint('); % or just int?
s=strrep(s,'floor(','floor(');
s=strrep(s,'mod(','modulo('); %mod exists but return negative values
% array stuff
s=regexprep(s,'size\(([^,]*)\)','shape($1)'); %replace size by reshape when no comma inside, otherwise, size is good
s=strrep(s,'length(','size('); % or count...

% math
s=strrep(s,'dot','dot_product'); %replace size by reshape when no comma inside, otherwise, size is good
s=strrep(s,'^','**'); 

% strings
s=strrep(s,'\','\\'); 

%% Things that are easily recognizable by their first position on the line
% case
s=regexprep(s,'^case([^!;]*)','case ($1) !');
s=regexprep(s,'^otherwise*)','case default ');
sold=s;
s=regexprep(sold,'^switch([^!;]*)','select case ($1) !');
if length(s)~=length(sold) % we did replace something
    % stacking
    end_stack=fstack_push(end_stack,'select');
end

% for replace
I=strfind(s,'for');
if ~isempty(I) && I(1)==1
    [ sf end_stack] = freplacefor( s , end_stack );
    return;
end
% while replace
I=strfind(s,'while');
if ~isempty(I) && I(1)==1
    [ sf end_stack] = freplacewhile( s , end_stack );
    return;
end

% if replace
I=regexp(s,'if\ |if\(|elseif|else\ if');
if ~isempty(I) &&  min(I)==1
    [ sf end_stack] = freplaceif( s , end_stack );
    return;
end

% end replace
I=strfind(s,'end');
if ~isempty(I) && I(1)==1  
    %let's check that this is not a variable
    if length(s)==3 || s(4)==' ' || s(4)==';' ||s(4)=='!'
        [ sf end_stack] = freplaceend( s , end_stack );
        return;
    end
end

% function calls
I=strfind(s,'[');
if ~isempty(I) && I(1)==1 
    [ sf] = freplacefunctioncall( s );
    return;
end

% brackets
% TODO with better string handling
% s=strrep(s,'[','(/');
% s=strrep(s,']','/)');
% multiline
s=strrep(s,'...','\&'); %char(8) not enough..  %HACK : the escape sequence is not recognize and hence it merges with the next line...


%% More tricky things that should require syntax parsing and recursion but that we'll not do!..
% zeros and ones
I=regexp(s,'(zeros\(|ones\(|linspace\()');
if ~isempty(I)
    [ s , decl_stack] = freplacezeros( s ,decl_stack);
else
    % stacking assignements so that they can be used for declarations
    [ s , decl_stack] = fassignement( s ,decl_stack);
end

% default return
sf=[s '\n'];
end %function






function fWriteDeclarationsAtCorrectLocation(fidftmp,fidf,Declarations)
current_unit=1;
sread = fgets(fidftmp);
while sread ~= -1
    if current_unit==1
        % wait for the first non comment empty to output the declaration
        if ~isempty(Declarations{1})  
            if ~isempty(sread) && sread(1)~='!'
                fprintf(fidf,'! Variable declarations \n');
                fwrite_Declarations(fidf,Declarations{current_unit});
                fprintf(fidf,'! \n');
                Declarations{1}=[];
            end
        end
    end
    I=strfind(sread,'subroutine');
    if ~isempty(I) && I(1)==1 
        %         if current_unit==1 && ~isempty(Declarations{current_unit})
        %             % case of first unit, i.e. main program 
        %             % % we need to output the declaration here
        %             fwrite_Declarations(fidf,Declarations{current_unit});
        %         end
        current_unit=current_unit+1;    %
    end
    I=strfind(sread,'!M2F-HERE-XXX');
    if ~isempty(I) && I(1)==1 
        fwrite_Declarations(fidf,Declarations{current_unit});
        sread='';
    end
    sread=strrep(sread,'\','\\'); % required 
    fprintf(fidf,sread);
    sread = fgets(fidftmp);
end %while reading file tmp
end %function fWriteDeclarationsAtCorrectLocation


function Declarations=fFormatDeclarations(Declarations,bSortDeclarationbyNames,bSortDeclarationbyTypes,bDebug)
for iud=1:length(Declarations)
    if bDebug
        fprintf(['-------------Declaration for unit ' num2str(iud) '\n']);
    end
    %             fprintf(2,Declarations{iud}{id});
    Decl=Declarations{iud};
    if length(Decl)>0 
        VarNames = cellfun(@(x)x.name, Decl, 'UniformOutput',false);
        % unique
        [~, Isort] = unique(VarNames); % NOTE: case ins-sensitive so that the user sees the possible clash since fortran is case insensitive
        [~, Isort2] = unique(lower(VarNames));
        if length(Isort)~=length(Isort2)
            warning('Be careful, there are variables that have the same characters but different cases.');
        end
        Decl=Decl(Isort);
        VarNames = cellfun(@(x)x.name, Decl, 'UniformOutput',false);
        VarTypes = cellfun(@(x)x.name, Decl, 'UniformOutput',false);

        % sorting
        if bSortDeclarationbyNames
            [~, Isort] = sort(lower(VarNames));  % NOTE: the lower here is a matter of choice
        elseif bSortDeclarationbyTypes
            [~, Isort] = sort(lower(VarTypes));
        else
            Isort=1:length(VarNames);
        end
        Decl=Decl(Isort);

        % Printing
        if bDebug
            fwrite_Declarations(1,Decl);
        end
    end
    Declarations{iud}=Decl;
end
end %function format Declarations


function []=fwrite_Declarations(fidout,Decl)
for id=1:length(Decl)
    [ sf ] = fgetDeclaration(Decl{id} );
    fprintf(fidout,sf);
end
end % function

